import React from 'react'
import PropTypes from 'prop-types'
import { TextField } from '@mui/material'

const User = props => {
  return (
    <div>
      <TextField id="outlined-basic" label="Outlined" variant="outlined" /> 
    </div>
  )
}

User.propTypes = {

}

export default User
